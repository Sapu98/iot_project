# iot_project

iot project, ll 99% del codice dell'app si trova nella cartella lib
