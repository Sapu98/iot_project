<?php

const key = 'MySecretKeyForEncryptionAndDecry'; // 32 chars
const iv = 'helloworldhellow'; // 16 chars
const method = 'aes-256-cbc';

function decrypt($text){
  return openssl_decrypt($text, method, key, 0, iv);
}

function encrypt($text){
  return openssl_encrypt($text, method, key, 0, iv);
}


function exitEncrypt($text){
  exit(encrypt($text));
}

function echoEncrypt($text){
  echo(encrypt($text));
}

?>