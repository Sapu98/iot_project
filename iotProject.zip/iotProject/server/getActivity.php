<?php

require_once('functions.php');
require_once('credentials.php');


$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exitEncrypt('Failed to connect to MySQL');
}

if (!isset($_POST['user_id'])) {
    exitEncrypt('User id parameter is missing!');
}

$user_id = intval(decrypt($_POST['user_id']));

//prende tutte le righe con user_id = id dell'utente che fa la richiesta
$sql = "SELECT * FROM activity WHERE user_id = '$user_id'";
if($result = mysqli_query($con, $sql)){
    if(mysqli_num_rows($result) > 0){
    //#=inizio riga 
    //*=nuovoValore
    $ciao = "";
        while($row = mysqli_fetch_array($result)){
        $ciao = $ciao . "#" . $row['id'] . "*" .$row['activity_name'] . "*" .$row['date_time'];
        }
        echoEncrypt("$ciao");
        
        mysqli_free_result($result);
    } else{
        echoEncrypt("No records matching your query were found.");
    }
} else{
    $error = mysqli_error($con);
    echoEncrypt("ERROR: $error");
}
 
$con->close();

?>