<?php

require_once('functions.php');
require_once('credentials.php');


$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exitEncrypt('Failed to connect to MySQL');
}

if (!isset($_POST['activity_name'], $_POST['date_time'], $_POST['user_id'], $_POST['coordPoints'])) {
    exitEncrypt('Error! please contact the dev (!isset)');
}

if (empty($_POST['activity_name']) || empty($_POST['date_time']) || empty($_POST['user_id']) || empty($_POST['coordPoints'])) {
    exitEncrypt('Error! please contact the dev (empty)');
}

$activity_name = decrypt($_POST['activity_name']);
$date_time = decrypt($_POST['date_time']);
$user_id = intval(decrypt($_POST['user_id']));
$coordPosList = explode(", ", decrypt($_POST['coordPoints']));
$last_id = -1;

if ($stmt = $con->prepare('INSERT INTO activity (activity_name, date_time, user_id) VALUES (?, ?, ?)')) {
    $stmt->bind_param('ssi', $activity_name, $date_time, $user_id);
    $stmt->execute();
    $last_id = $con->insert_id;
} else {
    echoEncrypt('Could not prepare statement! contact the developer');
}
$stmt->close();


if ($stmt = $con->prepare('INSERT INTO coord_point (activity_id, latitude, longitude, altitude, speed, date_time) VALUES (?, ?, ?, ?, ? ,?)')) {

    foreach ($coordPosList as $coord) {
        $coord = explode(" ", $coord);
        $activity_id = $last_id;
        $latitude = substr($coord[0], 9);
        $longitude = substr($coord[1], 10);
        $altitude = substr($coord[2], 9);
        $speed = substr($coord[3], 6);
        $date_time = substr($coord[4], 9) . " " . substr($coord[5], 0, -1);


        $stmt->bind_param('isssss', $activity_id, $latitude, $longitude, $altitude, $speed, $date_time);
        $stmt->execute();
    }
    echoEncrypt("Activity succesfully saved!");

} else {
    echoEncrypt('Could not prepare statement! contact the developer');
}
$stmt->close();
$con->close();
?>