<?php
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'sapu';
$DATABASE_PASS = 'dodici12';
$DATABASE_NAME = 'iot_project';
?>