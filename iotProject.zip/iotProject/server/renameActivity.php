<?php
require_once('functions.php');
require_once('credentials.php');

$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exitEncrypt('Failed to connect to MySQL');
}

if (!isset($_POST['activity_id']) || !isset($_POST['new_name'])) {
    exitEncrypt('Activity id parameter is missing!');
}

$activity_id = intval(decrypt($_POST['activity_id']));
$new_name = decrypt($_POST['new_name']);


if ($stmt = $con->prepare('UPDATE activity SET activity_name = ? WHERE id = ?')) {

    $stmt->bind_param('si', $new_name, $activity_id);
    $stmt->execute();
    echoEncrypt("Activity successfully renamed! $activity_id $new_name");
}
	
$con->close();

?>