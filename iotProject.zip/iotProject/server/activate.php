<?php

require_once('functions.php');
require_once('credentials.php');


$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

if (mysqli_connect_errno()) {
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}


if (isset($_GET['mail'], $_GET['code'])) {
	if ($stmt = $con->prepare('SELECT * FROM user WHERE mail = ? AND activation_code = ?')) {
		$stmt->bind_param('ss', $_GET['mail'], $_GET['code']);
		$stmt->execute();
		$stmt->store_result();
   //se l'acocunt esiste con il relativo activation_code
		if ($stmt->num_rows > 0) {
			if ($stmt = $con->prepare('UPDATE user SET activation_code = ? WHERE mail = ? AND activation_code = ?')) {
				$newcode = 'activated';
				$stmt->bind_param('sss', $newcode, $_GET['mail'], $_GET['code']);
				$stmt->execute();
				echo 'Your account is now activated, you can now login!';
			}
		} else {
			echo 'The account is already activated or doesn\'t exist!';
		}
	}
}
$con->close();
?>