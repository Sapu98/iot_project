<?php

require_once('functions.php');
require_once('credentials.php');

$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exitEncrypt('Failed to connect to MySQL');
}

if (!isset($_POST['mail'], $_POST['password'])) {
    exitEncrypt('Please fill both the email and password fields!');
}

$password = decrypt($_POST['password']);
$mail = decrypt($_POST['mail']);

if ($stmt = $con->prepare('SELECT id, password, username, activation_code FROM user WHERE mail = ?')) {
    $stmt->bind_param('s', $mail);
    $stmt->execute();
    //Salva il risultato della query per poter vedere se l'utente esiste gia
    $stmt->store_result();

//se esiste, ritorna la stringa di conferma.
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashpwd, $username, $activation_code);
        $stmt->fetch();
        if (password_verify($password, $hashpwd)) {
            $activation_code = $activation_code == "activated" ? "true" : "false";
            echoEncrypt("Successful login!#$username*$id*$activation_code");
        } else {
            echoEncrypt('Incorrect EMAIL or PASSWORD!');
        }
    } else {
        echoEncrypt('Incorrect EMAIL or PASSWORD!');
    }
    $stmt->close();
}
?>