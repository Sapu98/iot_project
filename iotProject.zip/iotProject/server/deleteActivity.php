<?php
require_once('functions.php');
require_once('credentials.php');

$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exitEncrypt('Failed to connect to MySQL');
}

if (!isset($_POST['activity_id'])) {
    exitEncrypt('Activityser id parameter is missing!');
}

$activity_id = intval(decrypt($_POST['activity_id']));


$sql = "DELETE FROM activity WHERE id = '$activity_id'";
if ($result = mysqli_query($con, $sql)) {

} else {
    $error = mysqli_error($con);
    exitEncrypt("ERROR: $error");
}

$sql = "DELETE FROM coord_point WHERE activity_id = '$activity_id'";
if ($result = mysqli_query($con, $sql)) {
    echoEncrypt("Activity successfully deleted!");
} else {
    $error = mysqli_error($con);
    exitEncrypt("ERROR: $error");
}

$con->close();

?>