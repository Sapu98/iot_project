<?php

require_once('functions.php');
require_once('credentials.php');

$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exitEncrypt('Failed to connect to MySQL');
}

if (!isset($_POST['username'], $_POST['password'], $_POST['mail'])) {
    exitEncrypt('Please complete the registration form! (isset)');
}

if (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['mail'])) {
    exitEncrypt('Please complete the registration form (empty)');
}

$password = decrypt($_POST['password']);
$mail = decrypt($_POST['mail']);
$username = decrypt($_POST['username']);

//controlli di formattazione
if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
    exitEncrypt('Email is not valid!');
}
if (preg_match('/^[A-Za-z0-9_]+$/', $username) == 0) {
    exitEncrypt('Username is not valid!');
}
if (strlen($password) > 32 || strlen($password) < 5) {
    exitEncrypt('Password must be between 5 and 32 characters long!');
}


if ($stmt = $con->prepare('SELECT id, password FROM user WHERE mail = ?')) {
    $stmt->bind_param('s', $mail);
    $stmt->execute();
    $stmt->store_result();
    //salva i risultati per controllare se l'account esiste gia
    if ($stmt->num_rows > 0) {
        exitEncrypt('Email already used!');
    } else {
//se invece non esiste, lo crea
        if ($stmt = $con->prepare('INSERT INTO user (mail, username, password, activation_code) VALUES (?, ?, ?, ?)')) {
            $hashPwd = password_hash($password, PASSWORD_DEFAULT);
            $uniqid = uniqid();
            $stmt->bind_param('ssss', $mail, $username, $hashPwd, $uniqid);
            $stmt->execute();

            //send confirmation mail
            $subject = 'Account Verification';
            $activate_link = 'http://sapu.hopto.org:20080/iotProject/activate.php?mail=' . $mail . '&code=' . $uniqid;
            $link = wordwrap($activate_link, 255, "\r\n");

            $message = '<div align="center" style="background-color: #f1f1f1;padding: 30px;">
    <img height="108" src="http://sapu.hopto.org:20080/iotProject/assets/appLogo.png" width="89">
<h2 style="font-family: Lato,serif">
    Please verify you email, ' . $username . '
</h2>
    </br>
<a href="' . $link . '"><img width="248" height="41" src="https://sapushrine.net/assets/button.png"></a>
</div>';

            $mail = $mail;
            exec("python mailVerifier/mailSender.py '$mail' '$subject' '$message'");
            echoEncrypt('Please check your email to activate your account! (dont forget to check your spam box)');

        } else {
            echoEncrypt('Could not prepare statement! contact the developer');
        }
    }
    $stmt->close();
} else {
    echoEncrypt('Could not prepare statement! contact the developer');
}
$con->close();
?>